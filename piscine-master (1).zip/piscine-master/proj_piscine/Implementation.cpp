#include "Implementation.h"
#include <string>


std::string choixFichier ()
{
    std::string fichier;
    std::cout<<"Entrez nom du fichier texte"<<std::endl;
    std::cin>>fichier;
    return fichier;
}

