#include <iostream>
#include "Implementation.h"
#include "Graphe.h"


int main()
{
    menu(); // Appel du menu

    return 0;
}
