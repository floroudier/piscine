#ifndef IMPLEMENTATION_H_INCLUDED
#define IMPLEMENTATION_H_INCLUDED
#include <iostream>
#include <string>


std::string choixFichier ();

#endif // IMPLEMENTATION_H_INCLUDED
